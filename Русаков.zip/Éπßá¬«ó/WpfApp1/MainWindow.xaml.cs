﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class LoginWindow : Window
    {
        private Entities2 db = new Entities2();
        private int userId;

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(UsernameInput.Text) || string.IsNullOrWhiteSpace(PasswordInput.Password))
                {
                    MessageBox.Show("Пожалуйста, заполните поля логина и пароля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var users = db.Пользователи.Where(u => u.Логин == UsernameInput.Text).ToArray();

                if (users.Length == 0)
                {
                    MessageBox.Show("Пользователь не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var currentUser = users[0];
                userId = currentUser.ID_пользователя;

                if (PasswordInput.Password == currentUser.Пароль)
                {
                    if (currentUser.active == true)
                    {
                        string message = $"Добро пожаловать, {currentUser.Имя}. Вы вошли как ";

                        switch (currentUser.Роль)
                        {
                            case 1:
                                MessageBox.Show(message + "Тренер.", "Успешный вход", MessageBoxButton.OK, MessageBoxImage.Information);
                                break;

                            case 2:
                                MessageBox.Show(message + "Администратор.", "Успешный вход", MessageBoxButton.OK, MessageBoxImage.Information);
                                new Window1().Show();
                                this.Close();
                                break;

                            case 3:
                                MessageBox.Show(message + "Клиент.", "Успешный вход", MessageBoxButton.OK, MessageBoxImage.Information);

                                if (currentUser.count >= 3)
                                {

                                }
                                else
                                {

                                }

                                this.Close();
                                break;

                            default:
                                MessageBox.Show("Не удалось определить роль пользователя.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                                break;
                        }

                        currentUser.count = 0;
                        db.SaveChanges();
                    }
                    else
                    {
                        MessageBox.Show("Доступ заблокирован. Свяжитесь с администратором.", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    currentUser.count++;

                    if (currentUser.count > 2)
                    {
                        currentUser.active = false;
                        db.SaveChanges();
                        MessageBox.Show("Вы были заблокированы после трёх неудачных попыток.", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        db.SaveChanges();
                        MessageBox.Show("Неверный логин или пароль. Попробуйте снова.", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла системная ошибка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
