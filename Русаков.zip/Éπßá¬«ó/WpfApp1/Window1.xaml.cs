﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;

namespace WpfApp1
{
    public partial class Window1 : Window
    {
        private Entities2 db = new Entities2();

        public Window1()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            // Загружаем роли
            var roles = db.Роли.ToArray();
            typeRole.DisplayMemberPath = "role1"; // Предполагается, что "role1" — это свойство класса Role
            typeRole.SelectedValuePath = "ID"; // Предполагается, что "ID" — это свойство класса Role
            typeRole.ItemsSource = roles;

            // Загружаем пользователей
            db.Пользователи.Load();
            GridUser.ItemsSource = db.Пользователи.Local.ToBindingList();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что все необходимые поля заполнены
            if (string.IsNullOrWhiteSpace(TextBox1.Text) ||
                string.IsNullOrWhiteSpace(TextBox2.Password) ||
                string.IsNullOrWhiteSpace(TextBox3.Text) ||
                string.IsNullOrWhiteSpace(TextBox4.Text) ||
                string.IsNullOrWhiteSpace(TextBox5.Text))
            {
                MessageBox.Show("Все поля должны быть заполнены!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var existingUser = db.Пользователи.FirstOrDefault(u => u.Логин == TextBox1.Text);
            if (existingUser != null)
            {
                MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Создаём нового пользователя
            Пользователи newUser = new Пользователи
            {
                Логин = TextBox1.Text,
                Пароль = TextBox2.Password,
                Роль = (typeRole.SelectedItem as Роли)?.ID ?? 0, // Берём ID роли, если выбрана роль
                Фамилия = TextBox3.Text,
                Имя = TextBox4.Text,
                Отчество = TextBox5.Text,
                count = 0,
                active = true,
                Номер_телефона = TextBox6.Text
                
            };

            db.Пользователи.Add(newUser);
            db.SaveChanges();

            // Обновляем данные на гриде
            GridUser.ItemsSource = db.Пользователи.ToList();

            MessageBox.Show("Данные успешно добавлены", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                db.SaveChanges();
                MessageBox.Show("Изменения сохранены.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения данных: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
